/***
*sys/timeb.h - definition/declarations for _ftime()
*
*       Copyright (c) Microsoft Corporation. All rights reserved.
*
*Purpose:
*       This file define the _ftime() function and the types it uses.
*       [System V]
*
*       [Public]
*
****/

#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include <crtdefs.h>
#include <time.h>

/* Non-ANSI name for compatibility */
struct timeb {
        time_t time;
        unsigned short millitm;
        short timezone;
        short dstflag;
        };
#define _timeb timeb
#define ftime _ftime

int __cdecl _ftime(struct timeb *tp);

#ifdef __cplusplus
}
#endif  /* __cplusplus */

